package go.main;

import java.util.HashSet;
import java.util.Set;


public class linkandzelda {
   
    private final Set<Intersection> links;

  
    private final Set<Intersection> liberties;

   
    private final Player owner;

 
    public linkandzelda(Set<Intersection> links, Set<Intersection> liberties, Player owner) {
        this.links = links;
        this.liberties = liberties;
        this.owner = owner;
    }

 
    public linkandzelda(Intersection intersection, Player owner) {
        links = new HashSet<Intersection>();
        links.add(intersection);
        this.owner = owner;
        liberties = new HashSet<Intersection>(intersection.getEmptyNeighbors());
    }

   
   
    public linkandzelda(linkandzelda linkandzelda) {
        this.links = new HashSet<Intersection>(linkandzelda.links);
        this.liberties = new HashSet<Intersection>(linkandzelda.liberties);
        this.owner = linkandzelda.owner;
    }

    
    public Player getOwner() {
        return owner;
    }

  
    public Set<Intersection> getLiberties() {
        return liberties;
    }

   
    public Set<Intersection> getlinks() {
        return links;
    }

 
    public void add(linkandzelda linkandzelda, Intersection playedStone) {
        // Fuse stone sets
        this.links.addAll(linkandzelda.links);
        // Fuse liberties
        this.liberties.addAll(linkandzelda.liberties);
        // remove played stone from liberties
        this.liberties.remove(playedStone);
    }

 
    public linkandzelda removeLiberty(Intersection playedStone) {
        linkandzelda newlinkandzelda = new linkandzelda(links, liberties, owner);
        newlinkandzelda.liberties.remove(playedStone);
        return newlinkandzelda;
    }

   
    public void die() {
        for (Intersection rollingStone : this.links) {
            rollingStone.setlinkandzelda(null);
            Set<linkandzelda> adjacentlinkandzeldas = rollingStone.getAdjacentlinkandzeldas();
            for (linkandzelda linkandzelda : adjacentlinkandzeldas) {
                linkandzelda.liberties.add(rollingStone);
            }
        }
        this.owner.addCapturedlinks(this.links.size());
    }
}
