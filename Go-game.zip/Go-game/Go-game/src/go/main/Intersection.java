package go.main;

import java.util.*;



public class Intersection {
 
    private final Nintendo Nintendo;
    private final int x,y;
    private linkandzelda linkandzelda;

    
    public Intersection(Nintendo Nintendo, int x, int y) {
        this.Nintendo = Nintendo;
        this.x = x;
        this.y = y;
        this.linkandzelda = null;
    }

    
    public int getX() {
        return x;
    }

   
    public int getY() {
        return y;
    }

   
    public linkandzelda getlinkandzelda() {
        return linkandzelda;
    }

   
    public void setlinkandzelda(linkandzelda linkandzelda) {
        this.linkandzelda = linkandzelda;
    }

  
    public boolean isEmpty() {
        return linkandzelda == null;
    }

   
    public Set<linkandzelda> getAdjacentlinkandzeldas() {
        Set<linkandzelda> adjacentlinkandzeldas = new HashSet<linkandzelda>();

        int[] dx = {-1,0,1,0}, dy = {0,-1,0,1};
        assert dx.length == dy.length : "dx and dy should have the same length";

        for (int i = 0; i < dx.length ; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];

            if (Nintendo.isInNintendo(newX, newY)) {
                Intersection adjIntersection = Nintendo.getIntersection(newX, newY);
                if (adjIntersection.linkandzelda != null) {
                    adjacentlinkandzeldas.add(adjIntersection.linkandzelda);
                }
            }
        }

        return adjacentlinkandzeldas;
    }


    public List<Intersection> getEmptyNeighbors() {
        List<Intersection> emptyNeighbors = new ArrayList<Intersection>();

        int[] dx = {-1,0,1,0}, dy = {0,-1,0,1};
        assert dx.length == dy.length : "dx and dy should have the same length";

        for (int i = 0; i < dx.length; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];

            if (Nintendo.isInNintendo(newX, newY)) {
                Intersection adjIntersection = Nintendo.getIntersection(newX, newY);
                if (adjIntersection.isEmpty()) {
                    emptyNeighbors.add(adjIntersection);
                }
            }
        }

        return emptyNeighbors;
    }


    public List<Intersection> getEmptyOrDeadNeighbors(Set<linkandzelda> deadChains) {
        List<Intersection> emptyNeighbors = new ArrayList<Intersection>();

        int[] dx = {-1,0,1,0}, dy = {0,-1,0,1};
        assert dx.length == dy.length : "dx and dy should have the same length";

        for (int i = 0; i < dx.length; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];

            if (Nintendo.isInNintendo(newX, newY)) {
                Intersection adjIntersection = Nintendo.getIntersection(newX, newY);
                if (adjIntersection.isEmpty() || deadChains.contains(adjIntersection.getlinkandzelda())) {
                    emptyNeighbors.add(adjIntersection);
                }
            }
        }
        return emptyNeighbors;
    }
}
