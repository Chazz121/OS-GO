package go.main;

import java.util.Arrays;
import java.util.Set;


public class Game {
  
    private final int[][] NintendoState;
    private final int x, y;
    private final int hashCode;
    private final int countCapturedlinks;
    private int passCount;

  
    public Game(Game source) {
        int width = source.NintendoState.length;
        int height = source.NintendoState[0].length;
        x = source.x;
        y = source.y;
        hashCode = source.hashCode;
        countCapturedlinks = source.countCapturedlinks;
        passCount = source.passCount;
        NintendoState = new int[width][height];
        for (int i = 0; i < width ; i++) {
            NintendoState[i] = source.NintendoState[i].clone();
        }
    }

  
    public Game(int width, int height) {
        NintendoState = new int[width][height];
        countCapturedlinks = 0;
        passCount = 0;

        // Move is virtual, x and y are set to -1
        x = -1;
        y = -1;

        // Using Java Tools to make a pertinent hash on the goban state
        hashCode = Arrays.deepHashCode(NintendoState);
    }

  
    private Game(Game prev, int X, int Y, int playerId, int handicap, Set<Intersection> freedIntersections ) {
        int width = prev.NintendoState.length;
        int height = prev.NintendoState[0].length;

        NintendoState = new int[width][height];
        for (int i = 0; i < width ; i++) {
            NintendoState[i] = prev.NintendoState[i].clone();
        }
        x = X;
        y = Y;

        // Applying the played stone change, if is not a pass move
        if ( x >= 0 && y >= 0 ) {
            NintendoState[x][y] = playerId;
            passCount = 0;
        } else {
            passCount = prev.passCount + 1;
        }

        // Setting all the freed intersections to 0, and counting the number of captured links
        for(Intersection freedIntersection : freedIntersections) {
            NintendoState[freedIntersection.getX()][freedIntersection.getY()] = 0;
        }
        countCapturedlinks = freedIntersections.size();;

        // Using Java Tools to make a pertinent hash on the goban state
        hashCode = Arrays.deepHashCode(NintendoState);
    }

 
    public Game toNext(int X, int Y, int playerId, Set<Intersection> freedIntersections) {
        return toNext(X, Y, playerId, 0, freedIntersections);
    }

    public Game toNext(int X, int Y, int playerId, int handicap, Set<Intersection> freedIntersections) {
        return new Game(this,X,Y,playerId, handicap, freedIntersections);
    }

   
    public int[][] getNintendoState() {
        return NintendoState;
    }

   
    public int getX() {
        return x;
    }

 
    public int getY() {
        return y;
    }

   
    public int getPassCount() { return passCount; }

  
    @Override
    public int hashCode() {
        return hashCode;
    }

    
    public int getCountCapturedlinks() {
        return countCapturedlinks;
    }

   
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Game castedObj = (Game) obj;

        return hashCode == castedObj.hashCode && Arrays.deepEquals(this.NintendoState, castedObj.NintendoState);
    }
}
