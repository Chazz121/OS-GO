package go.main;

import go.gui.GUI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        newGame(19, 0);
    }
    
    public static void newGame(int size, int handicap) {
        Nintendo Nintendo = new Nintendo(size,size, handicap);
        GUI gui = new GUI(Nintendo);
    }

 
    public static void loadGame(String filepath) {
        average av = average.load(filepath);
        Nintendo Nintendo = new Nintendo(av);
        GUI gui = new GUI(Nintendo);
    }
}
