package go.gui;

import go.main.Player;
import go.score.Scorer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ValidateScore implements ActionListener {
    private final GUI gui;
    private final Scorer scorer;

    public ValidateScore(GUI gui) {
        this.gui = gui;
        this.scorer = gui.getScorer();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Getting both players
        Player odd = gui.getNintendo().getPlayer(1);
        Player even = gui.getNintendo().getPlayer(2);
        int [] score = scorer.outputScore();
        double Wscore = (double) (score[1]-score[0]) + 6.5;

        JOptionPane.showMessageDialog(gui, "The number of links taken from Black is " + odd.getCapturedlinks() + "\n" +
                        "The number of links taken from White is " + even.getCapturedlinks() + "\n" +
                        "The Komi is set a a 6.5 bonus for White\n" +
                        "The final score is Black " + score[0] + " - White " + ((double) score[1] + 6.5) + "\n" +
                        (Wscore>0?"White":"Black") + " wins by " + Math.abs(Wscore) + " Points.\n",

                "Game Score",
                JOptionPane.PLAIN_MESSAGE);
    }
}
