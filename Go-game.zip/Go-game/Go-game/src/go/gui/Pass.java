package go.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import go.main.Nintendo;

public class Pass implements ActionListener {
    
    private GUI gui;

   
    public Pass(GUI gui) {
        this.gui = gui;
    }

  
    @Override
    public void actionPerformed(ActionEvent e) {
        Nintendo Nintendo = gui.getNintendo();
        if(Nintendo.getSuccessivePassCount() < 3) {
            Nintendo.pass(Nintendo.getPlayer());
            System.out.println("Pass applied");
            gui.updateNintendo();
            if(Nintendo.getSuccessivePassCount()==3) {
                gui.initScorer();
                gui.updateScore(null);
                gui.setPassEnabled(false);
                gui.setScoreEnabled(true);
            }
        }
    }
}