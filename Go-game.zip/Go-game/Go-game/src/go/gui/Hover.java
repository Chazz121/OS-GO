package go.gui;

import javax.swing.*;

import go.main.Nintendo;
import go.main.linkandzelda;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Hover extends MouseAdapter {
    int x,y;
    Nintendo Nintendo;
    JButton intersection;
    GUI gui;

    public Hover(int x, int y, JButton intersection , GUI gui) {
        this.x = x;
        this.y = y;
        this.Nintendo = gui.getNintendo();
        this.intersection = intersection;
        this.gui = gui;
    }


    @Override
    public void mouseEntered(MouseEvent e) {
        if(Nintendo.getSuccessivePassCount()<3) {
            if (Nintendo.getIntersection(x,y).getlinkandzelda()==null) {
                switch (Nintendo.getPlayer().getIdentifier()) {
                    case 1:
                        intersection.setIcon(Sprite.grid_p1);
                        break;
                    case 2:
                        intersection.setIcon(Sprite.grid_p2);
                        break;
                }
            } else {
                linkandzelda sc = Nintendo.getIntersection(x,y).getlinkandzelda();
                switch (sc.getOwner().getIdentifier()) {
                    case 1:
                        intersection.setIcon(Sprite.grid_p1_c);
                        break;
                    case 2:
                        intersection.setIcon(Sprite.grid_p2_c);
                        break;

                }
            }
        }
    }

   
    @Override
    public void mouseExited(MouseEvent e) {
        if(Nintendo.getSuccessivePassCount()<3) {
            linkandzelda sc = Nintendo.getIntersection(x,y).getlinkandzelda();
            if (sc != null) {
                if (sc.getOwner().getIdentifier() == 1) intersection.setIcon(Sprite.grid_p1);
                else intersection.setIcon(Sprite.grid_p2);
            } else {
                intersection.setIcon(Sprite.getGridIcon(Nintendo, x,y,0));
            }
        }
    }
}
