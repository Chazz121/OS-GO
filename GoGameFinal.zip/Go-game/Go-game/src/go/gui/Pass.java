package go.gui;

import go.core.Nintendo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pass implements ActionListener {
    
    private GUI gui;

   
    public Pass(GUI gui) {
        this.gui = gui;
    }

  
    @Override
    public void actionPerformed(ActionEvent e) {
        Nintendo Nintendo = gui.getNintendo();
        if(Nintendo.getSuccessivePassCount() < 3) {
            Nintendo.pass(Nintendo.getPlayer());
            System.out.println("Pass applied");
            gui.updateNintendo();
            if(Nintendo.getSuccessivePassCount()==3) {
                gui.initScorer();
                gui.updateScore(null);
                gui.setPassEnabled(false);
                gui.setScoreEnabled(true);
            }
        }
    }
}