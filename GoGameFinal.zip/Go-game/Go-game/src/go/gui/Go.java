package go.gui;

import go.core.Nintendo;
import go.core.Player;
import go.core.linkandzelda;
import go.score.Island;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Go implements ActionListener {

    private int x,y;


    private GUI gui;
    public Go(GUI gui, int x, int y) {
        super();

        this.gui = gui;
        this.x = x;
        this.y = y;
    }

 
    @Override
    public void actionPerformed(ActionEvent e) {
        if(gui.getNintendo().getSuccessivePassCount()<3) {
            Player player = gui.getNintendo().getPlayer();
            System.out.println(player+" want to play in ["+x+"-"+y+"]");
            try {
                if (gui.getNintendo().play(x, y, player)) {
                    System.out.println("Move applied");
                    gui.getNintendo().nextPlayer();
                    gui.updateNintendo();
                    gui.setUndoEnabled(true);
                    gui.setRedoEnabled(false);
                }
            } catch (Exception ex) {

            }
        } else {
            linkandzelda chain = gui.getNintendo().getIntersection(x,y).getlinkandzelda();
            gui.updateScore(chain);
        }
    }
}
