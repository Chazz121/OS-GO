package go.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class UndoRedo implements ActionListener {
    private boolean undo;
    private GUI gui;
    public UndoRedo(GUI gui, boolean undo) {
        this.gui = gui;
        this.undo = undo;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(gui.getNintendo().getSuccessivePassCount()<3 || undo) {
            if (undo) {
                // Undo action
                gui.setRedoEnabled(true);
                gui.getNintendo().undo();
                gui.setPassEnabled(true);
                gui.setScoreEnabled(false);
                if (!gui.getNintendo().getaverage().hasPreceding()) {
                    gui.setUndoEnabled(false);
                }
            } else {
                gui.setUndoEnabled(true);
                gui.getNintendo().redo();
                if (!gui.getNintendo().getaverage().hasFollowing()) {
                    gui.setRedoEnabled(false);
                }
            }
            gui.updateNintendo();
        }
    }
}