package go.core.exceptions;


public class OutOfNintendoException extends Exception {
 
    public OutOfNintendoException() {
    }


    public OutOfNintendoException(String message) {
        super(message);
    }


    public OutOfNintendoException(String message, Throwable cause) {
        super(message, cause);
    }

   
    public OutOfNintendoException(Throwable cause) {
        super(cause);
    }

   
    public OutOfNintendoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
