package go.core.exceptions;


public class InvalidGameEncounteredException extends Exception {
 
    public InvalidGameEncounteredException() {
    }
    
    public InvalidGameEncounteredException(String message) {
        super(message);
    }
    public InvalidGameEncounteredException(String message, Throwable cause) {
        super(message, cause);
    }
    public InvalidGameEncounteredException(Throwable cause) {
        super(cause);
    }
    public InvalidGameEncounteredException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
