package go.gui;

import go.core.Nintendo;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;


public class Sprite {
    public static final int TOKEN_INITIAL_SIZE = GUI.TOKEN_INITIAL_SIZE;


    private static final ImageIcon background = new ImageIcon(new ImageIcon("sprites/background.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE, TOKEN_INITIAL_SIZE, Image.SCALE_FAST));


    public static final ImageIcon grid_ul = new ImageIcon(new ImageIcon("sprites/ul.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_u = new ImageIcon(new ImageIcon("sprites/u.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_ur = new ImageIcon(new ImageIcon("sprites/ur.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_l = new ImageIcon(new ImageIcon("sprites/l.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_c = new ImageIcon(new ImageIcon("sprites/c.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_spot = new ImageIcon(new ImageIcon("sprites/spot.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_r = new ImageIcon(new ImageIcon("sprites/r.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_bl = new ImageIcon(new ImageIcon("sprites/bl.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_b = new ImageIcon(new ImageIcon("sprites/b.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    public static final ImageIcon grid_br = new ImageIcon(new ImageIcon("sprites/br.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));

    
    private static final ImageIcon p1 = new ImageIcon(new ImageIcon("sprites/p1.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_SMOOTH));
    private static final ImageIcon p2 = new ImageIcon(new ImageIcon("sprites/p2.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_SMOOTH));
    private static final ImageIcon wrong = new ImageIcon(new ImageIcon("sprites/wrong.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_SMOOTH));
    private static final ImageIcon mp1 = new ImageIcon(new ImageIcon("sprites/mp1.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));
    private static final ImageIcon mp2 = new ImageIcon(new ImageIcon("sprites/mp2.png").getImage().getScaledInstance(TOKEN_INITIAL_SIZE,TOKEN_INITIAL_SIZE, Image.SCALE_FAST));

   
    public static final ImageIcon grid_p1 = merge(new ArrayList<ImageIcon>(Arrays.asList(background, p1)));
    public static final ImageIcon grid_p2 = merge(new ArrayList<ImageIcon>(Arrays.asList(background, p2)));
    public static final ImageIcon grid_p1_c = merge(new ArrayList<ImageIcon>(Arrays.asList(background, p1, wrong)), new ArrayList<Float>(Arrays.asList(new Float(1.0), new Float(1.0), new Float(0.4))));
    public static final ImageIcon grid_p2_c = merge(new ArrayList<ImageIcon>(Arrays.asList(background, p2, wrong)), new ArrayList<Float>(Arrays.asList(new Float(1.0), new Float(1.0), new Float(0.4))));

    public static ImageIcon merge(ArrayList<ImageIcon> images) {
        ArrayList<Float> transparency = new ArrayList<Float>();

        for (ImageIcon i : images) {
            transparency.add(new Float(1.0));
        }

        return merge(images, transparency);
    }


    public static ImageIcon merge(ArrayList<ImageIcon> images, ArrayList<Float> transparency)
    {
        BufferedImage dest = null;
        Graphics2D destG = null;
        int rule; 
        float alpha;

        for (int i = 0, size = images.size(); i < size; i++)
        {
            Image image = images.get(i).getImage();

            rule = AlphaComposite.SRC_OVER; 
            alpha = transparency.get(i);

            if (i == 0)
            {
                dest = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);
                destG = dest.createGraphics();

                rule = AlphaComposite.SRC;
            }
            destG.setComposite(AlphaComposite.getInstance(rule, alpha));
            destG.drawImage(image, 0, 0, null);
        }

        return new ImageIcon(dest);
    }

 
    private static boolean shouldBeSpot(Nintendo Nintendo, int x, int y) {
        int NintendoWidth = Nintendo.getWidth();
        int NintendoHeight = Nintendo.getHeight();
        int offset = 3;
        if (NintendoWidth < 10) offset = 2;

        return (x == offset || x == (NintendoWidth-1)/2 || x == NintendoWidth-offset-1) && (y == offset || y == (NintendoHeight-1)/2 || y == NintendoHeight-offset-1);
    }

  
    public static ImageIcon getGridIcon(Nintendo Nintendo, int x, int y, int ownerID) {
        ImageIcon mp;

        switch (ownerID) {
            default:
                return getGridIcon(Nintendo, x, y);
            case 1:
                mp = mp1;
                break;
            case 2:
                mp = mp2;
                break;
        }

        return merge(new ArrayList<ImageIcon>(Arrays.asList(getGridIcon(Nintendo, x, y), mp)));
    }


    public static ImageIcon getGridIcon(Nintendo Nintendo, int x, int y) {
        int NintendoWidth = Nintendo.getWidth();
        int NintendoHeight = Nintendo.getHeight();

        if (x == NintendoWidth - 1) {
            if (y == 0) {
                return grid_ul;
            } else if (y == NintendoHeight - 1) {
                return grid_ur;
            } else {
                return grid_u;
            }
        } else if (x == 0) {
            if (y == 0) {
                return grid_bl;
            } else if (y == NintendoHeight - 1) {
                return grid_br;
            } else {
                return grid_b;
            }
        } else {
            if (y == 0) {
                return grid_l;
            } else if (y == NintendoHeight - 1) {
                return grid_r;
            } else {
                if (shouldBeSpot(Nintendo, x, y)) {
                    return grid_spot;
                } else {
                    return grid_c;
                }
            }
        }
    }

    public static ImageIcon getPlayerIcon(int player) {
        switch (player) {
            case 1:
                return grid_p1;
            case 2:
                return grid_p2;
            default:
                return null;
        }
    }

    public static ImageIcon getPlayerIcon(int player, int owner, Nintendo Nintendo, int x, int y) {
        if (player != owner) {
            switch (player) {
                case 1:
                    return merge(new ArrayList<ImageIcon>(Arrays.asList(getGridIcon(Nintendo, x, y), p1, mp2)), new ArrayList<Float>(Arrays.asList(new Float(1), new Float(0.6), new Float(1))));
                case 2:
                    return merge(new ArrayList<ImageIcon>(Arrays.asList(getGridIcon(Nintendo, x, y), p2, mp1)), new ArrayList<Float>(Arrays.asList(new Float(1), new Float(0.6), new Float(1))));
                default:
                    return null;
            }
        } else {
            return getPlayerIcon(player);
        }
    }
}
