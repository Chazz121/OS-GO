package go.core;

import go.core.exceptions.InvalidGameTurnEncounteredException;
import org.junit.Before;
import org.junit.Test;

import java.security.InvalidParameterException;
import java.util.Collections;
import java.util.Set;

import static org.junit.Assert.*;

public class NintendoTest {

    private Nintendo Nintendo,Nintendo9;
    private Player one , two ;

    @Before
    public void setUp() throws Exception {
        Nintendo = new Nintendo(3, 3);
        Nintendo9 = new Nintendo(9, 9);
        one = new Player(1);
        two = new Player(2);
        Nintendo9.play(Nintendo9.getIntersection(5,5),one);
        Nintendo9.play(Nintendo9.getIntersection(5,6),two);
        Nintendo9.play(Nintendo9.getIntersection(6,6),one);
        Nintendo9.play(Nintendo9.getIntersection(6,7),two);
        Nintendo9.play(Nintendo9.getIntersection(4,6),one);
        Nintendo9.play(Nintendo9.getIntersection(4,7),two);
        Nintendo9.play(Nintendo9.getIntersection(0,0),one);
        Nintendo9.play(Nintendo9.getIntersection(5,8),two);

    }


    @Test
    public void testIsInNintendo() throws Exception {
        assertTrue(Nintendo.isInNintendo(0, 0));
        assertFalse(Nintendo.isInNintendo(-1, 0));
        assertFalse(Nintendo.isInNintendo(0, -1));
        assertTrue(Nintendo.isInNintendo(2, 2));
        assertTrue(Nintendo.isInNintendo(0, 2));
        assertFalse(Nintendo.isInNintendo(3, 1));
        assertFalse(Nintendo.isInNintendo(1, 4));
        assertFalse(Nintendo.isInNintendo(5, 4));

        Intersection intersection = new Intersection(Nintendo, 1, 1);
        assertTrue(Nintendo.isInNintendo(intersection));
        intersection = new Intersection(Nintendo, 4, 2);
        assertFalse(Nintendo.isInNintendo(intersection));
    }

    @Test
    public void testIsValidMove() throws Exception {
        Intersection intersection = new Intersection(Nintendo, 1, 1);
        Player player = new Player(1);
        assertTrue(Nintendo.play(intersection, player));
        intersection = new Intersection(Nintendo, 1, 3);
        assertFalse(Nintendo.play(intersection, player));
    }

    @Test
    public void testPlayWithKo() throws Exception {
        assertTrue(Nintendo9.play(Nintendo9.getIntersection(5,7),one));
        assertFalse(Nintendo9.play(Nintendo9.getIntersection(5,6),two));
        assertTrue(Nintendo9.play(Nintendo9.getIntersection(2,2),two));
        assertTrue(Nintendo9.play(Nintendo9.getIntersection(1,1),one));
        assertTrue(Nintendo9.play(Nintendo9.getIntersection(5,6),two));
    }

    @Test
    public void testTakeGameTurn() throws Exception {
        GameTurn turn = new GameTurn(9,9);
        turn = turn.toNext(5, 5, 1, Collections.<Intersection>emptySet())
            .toNext(5,6,2,Collections.<Intersection>emptySet())
            .toNext(6,6,1,Collections.<Intersection>emptySet())
            .toNext(6,7,2,Collections.<Intersection>emptySet())
            .toNext(4,6,1,Collections.<Intersection>emptySet())
            .toNext(4,7,2,Collections.<Intersection>emptySet())
            .toNext(0,0,1,Collections.<Intersection>emptySet())
            .toNext(5,8,2,Collections.<Intersection>emptySet());

        Nintendo fromTurn = new Nintendo(9,9);
        fromTurn.takeGameTurn(turn,one,two);
        assertEquals(Nintendo9.toString(),fromTurn.toString());
    }

    @Test
    public void testPass() throws Exception {
        Nintendo9.pass(one);
        int x = Nintendo9.getGameRecord().getLastTurn().getX();
        int y = Nintendo9.getGameRecord().getLastTurn().getY();
        GameTurn state = Nintendo9.getGameRecord().getLastTurn();
        Nintendo9.getGameRecord().undo();
        GameTurn prevState = Nintendo9.getGameRecord().getLastTurn();
        assertEquals(-1,x);
        assertEquals(-1,y);
        assertEquals(prevState, state);
        assertFalse(prevState.toString()==state.toString());
    }

    @Test
    public void testPlayEquivalent() throws Exception {
        Nintendo NintendoTest = new Nintendo(9, 9);
        NintendoTest.play(5,5,one);
        NintendoTest.play(5,6,two);
        NintendoTest.play(6,6,one);
        NintendoTest.play(6,7,two);
        NintendoTest.play(4,6,one);
        NintendoTest.play(4,7,two);
        NintendoTest.play(0,0,one);
        NintendoTest.play(5,8,two);
        assertEquals(Nintendo9.toString(),NintendoTest.toString());
    }

    @Test
    public void testUndoRedo() throws Exception {
        assertFalse(Nintendo9.redo());
        assertTrue(Nintendo9.undo());
        assertTrue(Nintendo9.redo());
    }

    @Test
    public void testGetCapturedStones() throws Exception {
        assertTrue(Nintendo9.play(Nintendo9.getIntersection(5,7),one));
        Set<Intersection> set = Nintendo9.getLastCaptured();
        assertEquals(1,set.size());
        assertTrue(set.contains(Nintendo9.getIntersection(5, 6)));
    }

    @Test
    public void nextPreviousPlayer() throws Exception {
        Player even = Nintendo9.getPlayer();
        Nintendo9.nextPlayer();
        Player odd = Nintendo9.getPlayer();
        assertNotEquals(odd,even);
        Nintendo9.nextPlayer();
        assertEquals(even,Nintendo9.getPlayer());
        Nintendo9.nextPlayer();
        Nintendo9.nextPlayer();
        assertEquals(even,Nintendo9.getPlayer());
        Nintendo9.nextPlayer();
        assertEquals(odd,Nintendo9.getPlayer());
        Nintendo9.precedentPlayer();
        assertEquals(even,Nintendo9.getPlayer());
    }

    @Test
    public void testChangePlayer() throws Exception {
        Nintendo A = new Nintendo(9,9,4);
        assertEquals(4,A.getHandicap());
        GameRecord record = A.getGameRecord();

        record.apply(null); assertFalse(A.changePlayer(false)); // first handicap stone player is not changed
        record.undo();      assertFalse(A.changePlayer(true)); // undo , player is not changed
        record.apply(null); assertFalse(A.changePlayer(false)); // 1
        record.apply(null); assertFalse(A.changePlayer(false)); // 2
        record.apply(null); assertFalse(A.changePlayer(false)); // 3
        record.apply(null); assertFalse(A.changePlayer(false)); // 4
        record.apply(null); assertTrue(A.changePlayer(false)); // 5
        record.apply(null); assertTrue(A.changePlayer(true)); // 6
        record.undo();      assertTrue(A.changePlayer(true)); // UNDO
        record.undo();      assertTrue(A.changePlayer(true)); // UNDO
        record.undo();      assertFalse(A.changePlayer(true)); // UNDO but with handicap stones again
    }

    @Test
    public void badGameTurns() throws Exception {
        GameTurn A = new GameTurn(15,15);
        GameTurn B = null ;
        GameTurn D = new GameTurn(9,9).toNext(2,2,3,Collections.<Intersection>emptySet());
        try {
            Nintendo9.takeGameTurn(A,one,two);
            fail("Exception not thrown");
        } catch (InvalidGameTurnEncounteredException ex) {

        }
        try {
            Nintendo9.takeGameTurn(B,one,two);
            fail("Exception not thrown");
        } catch (InvalidParameterException ex) {

        }
        try {
            Nintendo9.takeGameTurn(D,one,two);
            fail("Exception not thrown");
        } catch (InvalidGameTurnEncounteredException ex) {

        }
    }

    @Test
    public void nullOutsideNintendo() throws Exception {
        assertNull(Nintendo9.getIntersection(10,10));
    }

    @Test
    public void getDimensions() throws Exception {
        assertEquals(9,Nintendo9.getWidth());
        assertEquals(9,Nintendo9.getHeight());
    }

    @Test
    public void testPassCount() throws Exception {
        assertEquals(0,Nintendo9.getSuccessivePassCount());
        Nintendo9.pass(Nintendo9.getPlayer());
        Nintendo9.pass(Nintendo9.getPlayer());
        assertEquals(2,Nintendo9.getSuccessivePassCount());
        Nintendo9.play(1,1,Nintendo9.getPlayer());
        assertEquals(0,Nintendo9.getSuccessivePassCount());

        Nintendo9.updatePassCount(true);
        Nintendo9.updatePassCount(true);
        Nintendo9.updatePassCount(true);
        Nintendo9.updatePassCount(true);
        assertEquals(4,Nintendo9.getSuccessivePassCount());
        Nintendo9.updatePassCount(false);
        assertEquals(0,Nintendo9.getSuccessivePassCount());
    }
}
