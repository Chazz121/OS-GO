package go.core;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Set;

public class linkandzeldaTest {

    private Nintendo Nintendo;
    private Player one, two;
    private linkandzelda chain1,chain2;

    @Before
    public void setUp() throws Exception {
        Nintendo = new Nintendo(9,9);
        one = new Player(1);
        two = new Player(2);

        chain1 = new linkandzelda(Nintendo.getIntersection(2,2),one);
            chain1.getlinks().add(Nintendo.getIntersection(2,3));
            for(Intersection stone : chain1.getlinks()) stone.setlinkandzelda(chain1);
            chain1.getLiberties().add(Nintendo.getIntersection(1,2));
            chain1.getLiberties().add(Nintendo.getIntersection(1,3));
            chain1.getLiberties().add(Nintendo.getIntersection(2,1));
            chain1.getLiberties().add(Nintendo.getIntersection(2,4));


        chain2 = new linkandzelda(Nintendo.getIntersection(3,2),two);
            chain2.getlinks().add(Nintendo.getIntersection(3,3));
            chain2.getlinks().add(Nintendo.getIntersection(3,4));
            for(Intersection stone : chain2.getlinks()) stone.setlinkandzelda(chain2);
            chain2.getLiberties().add(Nintendo.getIntersection(4,2));
            chain2.getLiberties().add(Nintendo.getIntersection(4,3));
            chain2.getLiberties().add(Nintendo.getIntersection(4,4));
            chain2.getLiberties().add(Nintendo.getIntersection(3,1));
            chain2.getLiberties().add(Nintendo.getIntersection(3,5));
            chain2.getLiberties().add(Nintendo.getIntersection(2,4));
    }

    @Test
    public void testAdd() throws Exception {
        assertFalse(chain1.getlinks().contains(Nintendo.getIntersection(2, 4)));
        assertTrue(chain1.getLiberties().contains(Nintendo.getIntersection(2, 4)));
        chain1.add(new linkandzelda(Nintendo.getIntersection(2,4),one),Nintendo.getIntersection(2,4));
        assertTrue(chain1.getlinks().contains(Nintendo.getIntersection(2,4)));
        assertFalse(chain1.getLiberties().contains(Nintendo.getIntersection(2,4)));
    }

    @Test
    public void testRemoveLiberty() throws Exception {
        assertTrue(chain1.getLiberties().contains(Nintendo.getIntersection(2,4)));
        chain1.removeLiberty(Nintendo.getIntersection(2,4));
        assertFalse(chain1.getLiberties().contains(Nintendo.getIntersection(2,4)));
    }

    @Test
    public void testDie() throws Exception {

        Set<Intersection> positions = chain1.getlinks();

        for (Intersection stone : positions ) {
            assertFalse(chain2.getLiberties().contains(stone));
            assertTrue(stone.getlinkandzelda()==chain1);
        }

        chain1.die();

        for (Intersection stone : positions ) {
            assertTrue(chain2.getLiberties().contains(stone));
            assertFalse(stone.getlinkandzelda()==chain1);
        }
    }

    @Test
    public void testDeepConstructor() throws Exception {
        linkandzelda chain3 = new linkandzelda(chain1);
        assertEquals(chain3.getLiberties(), chain1.getLiberties());
        assertEquals(chain3.getOwner(), chain1.getOwner());
        assertEquals(chain3.getlinks(), chain1.getlinks());
    }

    @Test
    public void testGetOwner() throws Exception {
        assertEquals(one, chain1.getOwner());
    }
}
